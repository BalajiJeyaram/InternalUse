﻿using System;
using System.Collections.Generic;
using System.IO;
namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ReadLine();
        }
 
    }

    public interface iCustomer:iSales
    {
        void Print();
        void Print(string Name);

    }

    public interface iSales
    {
        void Receipt();
    }

    public class Billing:iCustomer, iSales
    {
        Billing() { }

        public void Print() { }

        public void Print(string Name) { }

        public void Receipt() { }
    }


    
}


