﻿using System;
using System.Windows.Forms;
using ConsoleApp1;
namespace Demo_DesktopApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            ClearControls();
        }

        private void Button1_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Please enter a text!", "Demo DesktopApp", MessageBoxButtons.OK);
                textBox1.Focus();
                return;
            }
            
            try
            {
                label2.Text = TQuora.IsPalindrome(textBox1.Text.ToString()) == true ?
                string.Format("{0} is Palindrome", textBox1.Text.ToString()) :
                string.Format("{0} is not Palindrome", textBox1.Text.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Demo DesktopApp", MessageBoxButtons.OK);
            }

        }

        private void Button2_Click(object sender, EventArgs e)
        {
            ClearControls();
        }

        private void ClearControls()
        {
            textBox1.Text = string.Empty;
            textBox2.Text = string.Empty;
            label2.Text = string.Empty;
            label3.Text = string.Empty;
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ClearControls();
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            ClearControls();
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("Please enter a text!", "Demo DesktopApp", MessageBoxButtons.OK);
                textBox2.Focus();
                return;
            }
            if (int.TryParse(textBox2.Text.ToString(), out int result))
            {
                MessageBox.Show("Invali String","Demo DesktopApp",MessageBoxButtons.OK);
                textBox2.Focus();
                return;
            }
            try
            {
                label3.Text = TQuora.IsUnique(textBox2.Text.ToString()) == true ?
                string.Format("{0} is Unique", textBox2.Text.ToString()) :
                string.Format("{0} is not Unique", textBox2.Text.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Demo DesktopApp", MessageBoxButtons.OK);
            }
        }
    }
 
        
}
